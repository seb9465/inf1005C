#include <iostream>
#include <fstream>
#include <string>

using namespace std;

int main()
{
	ifstream lecture("scientifique.txt");

	string nomUtilisateur;
	bool nomTrouve = false;

	cout << "Entrez un nom : ";
	cin >> nomUtilisateur;

	/*string prenomUtilisateur = "";
	string nomFamilleUtilisateur = "";
	bool prenomTermine = false;
	for (int i = 0; i < nomUtilisateur.length(); i++)
	{
		prenomUtilisateur += nomUtilisateur[i];
	}*/



	while (lecture.peek() != EOF && !nomTrouve)
	{
		string nom = "";
		cin.clear();
		char carLu;
		lecture >> carLu;

		if (carLu != ';')
		{
			nom += carLu;
			cout << nom << endl;
		}
		else	// if (carLu == ';')
		{
			nomTrouve = nom == nomUtilisateur;
			nom = "";
		}
		


		
	}







	return 0;
}