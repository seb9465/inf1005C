#include <iostream>
#include <cmath>

using namespace std;

int main()
{

	double valeura = 0.0;
	double valeurInitiale = 0.0;

	double precision = 0.0;
	double ancienneValeur = 0.0;
	double valeur = 0.0;

	cout << "Entrez la valeur de A : ";
	cin >> valeura;
	cout << "Entrez la valeur de precision : ";
	cin >> precision;

	valeurInitiale = valeura / 2;

	valeur = valeurInitiale;
	ancienneValeur = valeura;

	while ((abs(valeur - ancienneValeur) / ancienneValeur) > precision)
	{
		ancienneValeur = valeur;
		valeur = ((ancienneValeur + (valeura / ancienneValeur)) / 2);
	}

	cout << "La racine carree de " << valeura << " est " << valeur << " avec une precision de " << precision << endl;

	return 0;
}