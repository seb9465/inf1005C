#include <iostream>

using namespace std;

int main()
{
	double nombre = 0;
	double reponse = 0;
	char option = '0';

	cout << "Entrez un nombre : ";
	cin >> nombre;

	cout << "Choisir une option parmi les suivantes : " << endl
		<< "carree (option 1)," << endl
		<< "racine (option 2)," << endl
		<< "cube (option 3)." << endl
		<< "Entrez le numero d'option correspondant : ";
	cin >> option;

	if (option == '1')
	{
		reponse = pow(nombre, 2);
	}
	else if (option == '2')
	{
		reponse = sqrt(nombre);
	}
	else if (option == '3')
	{
		reponse = pow(nombre, 3);
	}

	cout << "Resultat : " << reponse << endl;

	return 0;
}